const { EventEmitter } = require('events');
// EventEmitter class yang merupakan member events core module

const birthdayEventListener = (name) => {
    console.log(`Happy birthday ${name}!`);
  }

 const myEmitter = new EventEmitter();

 myEmitter.on('birthday', birthdayEventListener);

myEmitter.emit('birthday', 'ben');