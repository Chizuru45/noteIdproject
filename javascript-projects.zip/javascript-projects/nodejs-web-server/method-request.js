// clean code dengan menggunakan object destructuring seperti ini
const requestListener = (request, response) => {
    const { method } = request;

    if(method === 'GET') {
        // response ketika GET
    }

    if(method === 'POST') {
        // response ketika POST
    }

    // Anda bisa mengevaluasi tipe method lainnya seperti PUT, DELETE, dll
};
