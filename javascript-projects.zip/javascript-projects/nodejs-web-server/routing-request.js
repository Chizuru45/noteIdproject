const requestListener = (request, response) => {
    const { url } = request;

    if(url === '/') {
        // curl http://localhost:5000/
        if(method === 'GET') {
            // curl -X GET http://localhost:5000/
        }
        
        // curl -X <any> http://localhost:5000/
    }

    if(url === '/about') {
        // curl http://localhost:5000/
        if(method === 'GET') {
            // curl -X GET http://localhost:5000/about
        }

    if(method === 'POST') {
        // curl -X POST http://localhost:5000/about
    }

        // curl -X <any> http://localhost:5000/about
  }

    //  curl http://localhost:5000/<any>
};